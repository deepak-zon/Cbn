<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="col-md-12">
	<h4 class="bold well email-template-heading">
		<?php echo _l('reminder_templates'); ?>
		<?php if($hasPermissionEdit){ ?>
			<a href="<?php echo admin_url('emails/disable_by_type/reminder'); ?>" class="pull-right mleft5 mright25"><small><?php echo _l('disable_all'); ?></small></a>
			<a href="<?php echo admin_url('emails/enable_by_type/reminder'); ?>" class="pull-right"><small><?php echo _l('enable_all'); ?></small></a>
		<?php } ?>

	</h4>
	<div class="table-responsive">
		<table class="table table-bordered">
			<thead>
				<tr>
					<th><?php echo _l('reminder_custome_templates_table_heading_name'); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($reminders as $reminder){ ?>
					<tr>
						<td class="<?php if($reminder['active'] == 0){echo 'text-throught';} ?>">
							<a href="<?php echo admin_url('emails/email_template/'.$reminder['emailtemplateid']); ?>"><?php echo $reminder['name']; ?></a>
							<?php if(ENVIRONMENT !== 'production'){ ?>
								<br/><small><?php echo $reminder['slug']; ?></small>
							<?php } ?>
							<?php if($hasPermissionEdit){ ?>
								<a href="<?php echo admin_url('emails/'.($reminder['active'] == '1' ? 'disable/' : 'enable/').$reminder['emailtemplateid']); ?>" class="pull-right"><small><?php echo _l($reminder['active'] == 1 ? 'disable' : 'enable'); ?></small></a>
							<?php } ?>
						</td>
					</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
</div>